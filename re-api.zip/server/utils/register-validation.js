var validator = require('validator');

var validateRegisterdUser = (inputes)=>{

}

module.exports = {
    registerRes:validateRegisterdUser
}