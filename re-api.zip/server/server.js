/* global imports */
var express = require('express');
var bodyparser = require('body-parser');
var hbs = require('hbs');
/* local imports */
var {mongoose} = require("./db/mongoose");
var {usermodel} = require('./user/user');
var {authenticate} = require('./authenticate/authenticate');

var app = express();

app.use(bodyparser.urlencoded({ extended: true })); 
app.use(bodyparser.json());

app.set('view engine','hbs');
const PORT = process.env.PORT || 3000;
app.get('/',(req,res)=>{
    res.render(__dirname+"/views/home.hbs");
})

app.post('/newuser',(req,res)=>{
    var name = req.body.name;
    var email = req.body.email;
    var contact = req.body.contact;
    var password = req.body.password;
    
    var newUser = new usermodel({
        name,email,contact,password
    });
    
    newUser.generateAuthToken().then((token)=>{
        //res.header({'x-auth':token});
        res.header({'x-auth':token}).send(newUser);
        
    }).catch((err)=>{
        res.status(400).send(err);
    })
    
})

/* == first private route == */
app.get('/user/me',authenticate, (req,res)=>{
    res.send({status:1,data:req.user,text:"life to settle hai"});
})
/* == for view user in webpage == */ 
app.get("/getUser",(req,res)=>{
    usermodel.find().then((succ)=>{
        res.render(__dirname+"/views/user-list.hbs",{status:1,data:succ});
    },(err)=>{
        res.status(404).send()
    })
})

/* ==for user login == */
app.post('/userLogin',(req,res)=>{

    var user = {'email':req.body.email,'password':req.body.password};
    usermodel.authenticateUser(user.email,user.password).then((valid_user)=>{
        
        return valid_user.res.generateAuthToken().then((token)=>{
            res.header({'x-auth':token}).send(valid_user);
        })
    }).catch((e)=>{
        res.send(e);
    })

})
app.listen(PORT,()=>{
    
    console.log(`Server is runing on port ${PORT}`);
})